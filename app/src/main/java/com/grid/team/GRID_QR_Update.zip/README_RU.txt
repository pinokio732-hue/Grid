GRID QR update

1. Replace app/src/main/java/com/grid/team/MainActivity.java with the included file.
2. In app/build.gradle (or app/build.gradle.kts) add ZXing Android Embedded dependency:
   Groovy: implementation 'com.journeyapps:zxing-android-embedded:4.3.0'
   Kotlin: implementation("com.journeyapps:zxing-android-embedded:4.3.0")
3. Ensure repositories include google() and mavenCentral().
4. Build APK in GitHub Actions. Install over existing app without uninstalling it.

Host: SYNC > Start server > QR shown. Client: SYNC > Scan QR code.
Both phones need same trusted Wi-Fi. QR contains IP and temporary 8-digit PIN; do not share publicly.
Existing manual IP/PIN connection remains.

IMPORTANT: This source has not been compiled in this environment.
